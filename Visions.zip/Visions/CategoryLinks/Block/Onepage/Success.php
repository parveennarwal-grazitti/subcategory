<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Visions\CategoryLinks\Block\Onepage;

use Magento\Customer\Model\Context;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Address;
use Magento\Sales\Model\Order\Address\Renderer as AddressRenderer;

/**
 * One page checkout success page
 *
 * @api
 * @since 100.0.2
 */

    class Success extends \Magento\Checkout\Block\Onepage\Success 
    {

        protected $_orderDetail;

        protected $_order;

        protected $_item;

        protected $_renderer;
        protected $addressRenderer;

        protected $_priceHelper;

        protected $_customerSession;

        /**
         * @param \Magento\Framework\View\Element\Template\Context $context
         * @param \Magento\Checkout\Model\Session $checkoutSession
         * @param \Magento\Sales\Model\Order\Config $orderConfig
         * @param \Magento\Framework\App\Http\Context $httpContext
         * @param array $data
         */
        public function __construct(
            AddressRenderer $addressRenderer,
            \Magento\Framework\View\Element\Template\Context $context,
            \Magento\Checkout\Model\Session $checkoutSession,
            \Magento\Sales\Model\Order\Config $orderConfig,
            \Magento\Framework\App\Http\Context $httpContext,
            \Magento\Sales\Model\Order $orderDetails,
            \Magento\Catalog\Model\ProductRepository $item,
            \Magento\Sales\Model\Order\Address\Renderer $renderer,
            \Magento\Framework\Pricing\Helper\Data $priceHelper,
            \Magento\Catalog\Block\Product\ListProduct $listProduct,
            \Magento\Store\Model\StoreManagerInterface $storeManager,
            \Magento\Customer\Model\Session $customerSession,
            array $data = []
        ) {

            $this->_orderDetail = $orderDetails;
            $this->_renderer = $renderer;
            $this->addressRenderer = $addressRenderer;
            $this->_item = $item;
            $this->_priceHelper = $priceHelper;
            $this->_listProduct = $listProduct;
            $this->_storeManager = $storeManager;
            $this->_customerSession = $customerSession;
            $this->_order = null;
            parent::__construct(
                    $context, $checkoutSession, $orderConfig, $httpContext, $data
            );
        }

        public function getOrder($id) {
            $this->_order = $this->_orderDetail->loadByIncrementId($id);
            return $this->_order;
        }

        public function getItem($itemId) {
            return $this->_item->getById($itemId);
        }

        public function getFormatedAddress($address) {
            return $this->_renderer->format($address, 'html');
        }

        public function getPaymentMethodtitle($order) {
            $payment = $order->getPayment();
            $method = $payment->getMethodInstance();
            return $method->getTitle();
        }

        /**
         * Get Formated Price
         * @param fload price 
         * @return boolean
        */
        public function getFormatedPrice($price='')
        {
            return $this->_priceHelper->currency($price, true, false);
        }

        public function getMediaUrl()
        {
            $currentStore = $this->_storeManager->getStore();
            return $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        }
        /**
     * Returns string with formatted address
     *
     * @param Address $address
     * @return null|string
     */
    public function getFormattedAddress(Address $address)
    {
        return $this->addressRenderer->format($address, 'html');
    }   

}

    