<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Marketplace
 * @author    Webkul
 * @copyright Copyright (c) 2010-2018 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */

namespace Visions\CategoryLinks\Helper;
use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	protected $_objectManager;
	protected $_customerSession;

	public function __construct(\Magento\Framework\App\Helper\Context $context,
		 \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\ObjectManagerInterface $objectManager)
	{
        $this->_objectManager = $objectManager;
        $this->_customerSession = $customerSession;
	}


  	public function getcustomerSession()
       {
	      return  $this->_customerSession;
       }
}