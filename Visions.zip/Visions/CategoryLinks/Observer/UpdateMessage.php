<?php
namespace Visions\CategoryLinks\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Action\HttpPostActionInterface as HttpPostActionInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Checkout\Model\Cart as CustomerCart;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Controller for processing add to cart action.
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */

class UpdateMessage implements ObserverInterface
{
    /** @var \Magento\Framework\Message\ManagerInterface */
    protected $messageManager;

    /** @var \Magento\Framework\UrlInterface */
    protected $url;
    protected $cart;

    public function __construct(
        \Magento\Framework\Message\ManagerInterface $managerInterface,
        \Magento\Framework\UrlInterface $url,
         \Magento\Checkout\Model\Cart $cart
    ) {
        $this->messageManager = $managerInterface;
        $this->url = $url;
        $this->cart = $cart;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) {
    $itemsCollection = $this->cart->getQuote()->getItemsCollection();
    $itemsVisible = $this->cart->getQuote()->getAllVisibleItems();
    $items = $this->cart->getQuote()->getAllItems();

    foreach($items as $item) 
    {
        $productname=$item->getName();            
    }
        $messageCollection = $this->messageManager->getMessages(true);
        $cartLink = 'You added'.' '.$productname.' '.'in your'.' '.'<a href="'. $this->url->getUrl('checkout/cart') .'">shopping Cart</a>';
        $this->messageManager->addSuccess($messageCollection->getLastAddedMessage() . '  ' . $cartLink);
    }
}
